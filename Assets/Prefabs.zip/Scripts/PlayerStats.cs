using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public int punkty = 0;
    public int poziomGrubosci = 0;

    [SerializeField]
    private Drum[] drums;

    private void OnEnable()
    {
        foreach (Drum drum in drums) {
            drum.OnDrumHit += OnNoteHit;
        }
    }

    private void OnDisable()
    {
        foreach (Drum drum in drums) {
            drum.OnDrumHit -= OnNoteHit;
        }
    }

    private void OnNoteHit(Drum drum, bool hit, FallingNote.NoteType noteType, float distance)
    {
        if(!hit)
        {
            punkty--;
            //Miss!
            return;
        }

        if (noteType == FallingNote.NoteType.Good)
        {
            Debug.Log(distance);

            if(distance < 0.1f)
            {
                punkty += 100;
                Debug.Log("PERFECT!");
            } else if (distance < 0.2f)
            {
                punkty += 10;
                Debug.Log("GOOD!");
            } else
            {
                punkty += 1;
                Debug.Log("Zno�nie");
            }
        } else
        {
            punkty--;
            //Burger
        }
    }

    public void GivePoints(int ile)
    {
        punkty = punkty + ile;
    }

    public void MinusPoints(int ile)
    {
        if (punkty >= 0)
        {
            punkty = punkty - ile;
        }
        else
        {
            punkty = 0;
        }
        Debug.Log("Ilo�� punkt�w: " + punkty);
    }



    
}

