using DG.Tweening;
using UnityEngine;
using UnityEngine.Rendering;

public class FallingNote : MonoBehaviour
{
    public enum MoveMode
    {
        Stepped, // krok na każdy beat (DOTween)
        Smooth   // płynny ruch zależny od pozycji w utworze
    }

    public enum NoteType
    {
        Good,
        Bad
    }

    [SerializeField] private MoveMode moveMode = MoveMode.Stepped;
    [SerializeField] private Ease stepEase = Ease.OutQuad;

    [field: SerializeField]
    public NoteType noteType { get; private set; }

    private int _hitBeat;
    private int _spawnBeat;
    private int _steps;
    private float _startY;
    private float _targetY;

    private Tween _tween;
    private bool _initialized;
    private bool _subscribed;

    public int HitBeat => _hitBeat;

    /// <summary>
    /// Wywoływane przez spawner zaraz po Instantiate (na beacie hitBeat - steps).
    /// </summary>
    public void Init(int hitBeat, int steps, float startY, float targetY)
    {
        _hitBeat = hitBeat;
        _steps = steps;
        _spawnBeat = hitBeat - steps;
        _startY = startY;
        _targetY = targetY;

        Vector3 p = transform.position;
        p.y = startY;
        transform.position = p;

        _initialized = true;

        if (moveMode == MoveMode.Stepped)
        {
            Conductor.Instance.OnBeatAhead += HandleBeatAhead;
            _subscribed = true;
        }
    }

    private void Update()
    {
        if (!_initialized || moveMode != MoveMode.Smooth)
            return;

        float t = (float)((Conductor.Instance.SongPositionInBeats - _spawnBeat) / _steps);
        t = Mathf.Clamp(t, 0, Mathf.Infinity);

        Vector3 p = transform.position;
        p.y = _startY - (_startY - _targetY) * t;
        //p.y = Mathf.Lerp(_startY, _targetY, t);
        transform.position = p;

        if (p.y < -8)
            DestroyNote(false);
    }

    // Wywołane MoveDuration przed beatem "beat" - tween kończy się dokładnie na tym beacie.
    private void HandleBeatAhead(int beat)
    {
        int step = beat - _spawnBeat; // numer kroku: 1..steps
        /*if (step < 1 || step > _steps)
            return;*/

        // Cel liczony absolutnie, więc ewentualny poślizg nie kumuluje się.
        //float y = Mathf.Lerp(_startY, _targetY, (float)step / _steps);

        float y = _startY - (_startY - _targetY) * ((float)step / _steps);

        _tween?.Kill(true); // dokończ poprzedni krok (snap do jego celu)
        _tween = transform.DOMoveY(y, Conductor.Instance.MoveDuration).SetEase(stepEase);

        /*if (step == _steps)
            Unsubscribe();*/

        if(y < -8)
        {
            DestroyNote(false);
        }
    }

    public void DestroyNote(bool hitCorrectly)
    {
        if(hitCorrectly)
        {
            //Tu ladny efekt
        }

        Unsubscribe();
        Destroy(gameObject);
    }

    private void Unsubscribe()
    {
        if (!_subscribed)
            return;

        if (Conductor.Instance != null)
            Conductor.Instance.OnBeatAhead -= HandleBeatAhead;

        _subscribed = false;
    }

    private void OnDestroy()
    {
        Unsubscribe();
        _tween?.Kill();
    }
}
